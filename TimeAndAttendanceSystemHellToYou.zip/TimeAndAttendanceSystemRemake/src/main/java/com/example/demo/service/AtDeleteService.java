package com.example.demo.service;

import com.example.demo.entity.EmpAtData;

public interface AtDeleteService {

	void remove(EmpAtData ead);

}
