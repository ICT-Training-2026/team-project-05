package com.example.demo.service;

import com.example.demo.entity.EmpAtData;

public interface AtEditService {

	void edit(EmpAtData ead);

}
