package com.example.demo.form;

import lombok.Data;

@Data
public class AtSearchForm {
	
	private int emp_num;
	
}
