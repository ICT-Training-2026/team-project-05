package com.example.demo.service;

import com.example.demo.entity.EmpAtData;

public interface AtRegistService {

	void regist(EmpAtData ead);

}
