package com.example.demo.form;

import lombok.Data;

@Data
public class AtLoginForm {
	
	private String emp_num;
	private String emp_pass;
	private int auth_code;
	
}
