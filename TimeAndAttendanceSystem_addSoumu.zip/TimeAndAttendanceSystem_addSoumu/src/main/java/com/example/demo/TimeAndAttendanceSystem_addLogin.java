package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TimeAndAttendanceSystem_addLogin {

	public static void main(String[] args) {
		SpringApplication.run(TimeAndAttendanceSystem_addLogin.class, args);
	}

}
